import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
 
/**
 * JBackground - Botón personalizado de Swing que abre un explorador de archivos
 * y pone la imagen seleccionada como fondo del JFrame padre.
 *
 * Compatible con formularios de NetBeans (AbsoluteLayout).
 * Deja el actionPerformed del form vacio.
 */
public class JBackground extends JButton {
 
    // Interfaz tipo listener (para avisar cuando cambia el fondo)

    public interface ListenerCambioFondo {
        void fondoCambiado(BufferedImage imagen);
    }
 

    // Variables internas

    private BufferedImage imagenActual; // guarda la imagen actual
    private final java.util.List<ListenerCambioFondo> Listeners = new java.util.ArrayList<>();
    private final JFileChooser selectorArchivos = construirSelectorArchivos(); // explorador de archivos
    private PanelFondo overlayPanel; // panel que dibuja la imagen
 

    // Constructores

    public JBackground() {
        this("Cambiar fondo");
    }
 
    public JBackground(String texto) {
        super(texto);
        estilizarBoton(); // aplica estilos al botón
        addActionListener(e -> manejarClick()); // al hacer click pasa todo
    }
 

    // Métodos públicos (API)

    public BufferedImage obtenerImagenActual() { return imagenActual; }
 
    public void establecerImagenFondo(BufferedImage imagen) {
        imagenActual = imagen;
        aplicarAlFrame(imagen); // aplica la imagen al frame
        notificarListeners(imagen); // notifica a quien esté escuchando
    }
 
    public void limpiarFondo() {
        imagenActual = null;
        if (overlayPanel != null) {
            overlayPanel.setImage(null);
            overlayPanel.repaint();
        }
    }
 
    public void agregarListenerCambioFondo(ListenerCambioFondo l) {
        if (l != null) Listeners.add(l);
    }
 
    public void eliminarListenerCambioFondo(ListenerCambioFondo l) {
        Listeners.remove(l);
    }
 

    // Lógica principal

    private void manejarClick() {
        // Busca la ventana padre (el JFrame básicamente)
        Window ventana = SwingUtilities.getWindowAncestor(this);
 
        int resultado = selectorArchivos.showOpenDialog(ventana);
        if (resultado != JFileChooser.APPROVE_OPTION) return;
 
        File archivo = selectorArchivos.getSelectedFile();
        try {
            BufferedImage img = ImageIO.read(archivo);
 
            // Si no es imagen válida
            if (img == null) {
                JOptionPane.showMessageDialog(ventana,
                        "El archivo seleccionado no es una imagen válida:\n" + archivo.getName(),
                        "Imagen inválida", JOptionPane.WARNING_MESSAGE);
                return;
            }
 
            imagenActual = img;
            aplicarAlFrame(img); // aplica fondo
            notificarListeners(img); // avisa a listeners
 
        } catch (IOException e) {
            JOptionPane.showMessageDialog(ventana,
                    "No se pudo leer el archivo:\n" + e.getMessage(),
                    "Error de lectura", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    private void aplicarAlFrame(BufferedImage imagen) {
        JFrame frame = encontrarFramePadre();
        if (frame == null) return;
 
        JLayeredPane layeredPane = frame.getLayeredPane();
        Container contentPane = frame.getContentPane();
 
        // Paso 1: crear el panel de fondo solo una vez
        if (overlayPanel == null) {
            overlayPanel = new PanelFondo();
 
            // Lo metemos debajo del contenido para no tapar botones ni nada (No funciono)
            layeredPane.add(overlayPanel, JLayeredPane.FRAME_CONTENT_LAYER - 1);
 
            // Si el frame cambia de tamanio, el fondo también
            layeredPane.addComponentListener(new ComponentAdapter() {
                @Override
                public void componentResized(ComponentEvent e) {
                    sincronizarTamanoOverlay(layeredPane);
                }
            });
        }
 
        // Paso 2: poner imagen y tamanio
        overlayPanel.setImage(imagen);
        sincronizarTamanoOverlay(layeredPane);
 
        // Paso 3: hacer transparente el contentPane
        // Esto permite que se vea el fondo sin romper los componentes (Tampoco funciono)
        if (contentPane instanceof JComponent) {
            ((JComponent) contentPane).setOpaque(false);
        }
 
        // Paso 4: redibujar TODO
        // Esto fuerza a Swing a respetar el orden de capas (Tampoco funciono)
        SwingUtilities.invokeLater(() -> {
            layeredPane.revalidate();
            layeredPane.repaint();
            contentPane.repaint(); // asegura que botones y demás vuelvan a aparecer bien (Mentira)
        });
    }
 
    private void sincronizarTamanoOverlay(JLayeredPane layeredPane) {
        if (overlayPanel != null) {
            overlayPanel.setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight());
        }
    }
 
    private JFrame encontrarFramePadre() {
        Window w = SwingUtilities.getWindowAncestor(this);
        if (w instanceof JFrame) return (JFrame) w;
 
        // fallback por si algo raro pasa
        for (Window win : Window.getWindows()) {
            if (win instanceof JFrame && win.isShowing()) return (JFrame) win;
        }
        return null;
    }
 
    private void notificarListeners(BufferedImage imagen) {
        for (ListenerCambioFondo l : Listeners) l.fondoCambiado(imagen);
    }
 

    // Estilo del botón (solo estética)

    private void estilizarBoton() {
        setBackground(new Color(55, 110, 195));
        setForeground(Color.WHITE);
        setFocusPainted(false);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(35, 80, 155), 1),
                BorderFactory.createEmptyBorder(6, 14, 6, 14)));
        setFont(new Font("SansSerif", Font.BOLD, 13));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setToolTipText("Click para elegir imagen de fondo");
 
        addMouseListener(new MouseAdapter() {
            final Color normal = new Color(55, 110, 195);
            final Color hover  = new Color(35,  85, 165);
            @Override public void mouseEntered(MouseEvent e) { setBackground(hover); }
            @Override public void mouseExited (MouseEvent e) { setBackground(normal); }
        });
    }
 
    private static JFileChooser construirSelectorArchivos() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Seleccionar imagen de fondo");
        fc.setAcceptAllFileFilterUsed(false);
 
        fc.addChoosableFileFilter(new FileNameExtensionFilter(
                "Imágenes (*.jpg, *.jpeg, *.png, *.gif, *.bmp)",
                "jpg", "jpeg", "png", "gif", "bmp"));
 
        return fc;
    }
 

    // Clase interna: panel que dibuja la imagen
 
    /**
     * Este panel es el que pinta la imagen.
     * Vive en una capa debajo del contenido, así nunca tapa botones. (Ojala hubiera sido asi)
     */
    static class PanelFondo extends JPanel {
 
        private BufferedImage imagen;
 
        PanelFondo() {
            setOpaque(true); // cubre completamente el fondo
        }
 
        void setImage(BufferedImage imagen) {
            this.imagen = imagen;
        }
 
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (imagen == null) return;
 
            Graphics2D g2 = (Graphics2D) g.create();
 
            // Mejor calidad de escalado
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                    RenderingHints.VALUE_RENDER_QUALITY);
 
            int pw = getWidth(),  ph = getHeight();
            int iw = imagen.getWidth(), ih = imagen.getHeight();
 
            // Modo cover (tipo CSS): llena todo sin deformar
            double scale = Math.max((double) pw / iw, (double) ph / ih);
            int dw = (int) (iw * scale);
            int dh = (int) (ih * scale);
            int dx = (pw - dw) / 2;
            int dy = (ph - dh) / 2;
 
            g2.drawImage(imagen, dx, dy, dw, dh, null);
            g2.dispose();
        }
    }
}