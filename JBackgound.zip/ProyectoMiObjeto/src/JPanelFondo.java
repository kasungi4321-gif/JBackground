import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;

public class JPanelFondo extends JPanel {

    private BufferedImage imagen;

    public JPanelFondo() {
        setLayout(new BorderLayout());
    }
    
    public String seleccionarImagen() {

        JFileChooser fileChooser = new JFileChooser();

        // filtro para imágenes
        FileNameExtensionFilter filtro = new FileNameExtensionFilter(
                "png", "jpg", "jpeg", "png", "gif", "bmp");

        fileChooser.setFileFilter(filtro);

        int resultado = fileChooser.showOpenDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {

            File archivo = fileChooser.getSelectedFile();

            return archivo.getAbsolutePath();
        }

        return null;
    }

    public boolean esImagenValida(String ruta) {

        try {
            BufferedImage img = ImageIO.read(new File(ruta));
            return img != null;
        } catch (Exception e) {
            return false;
        }
    }
    

    public void cambiarFondo(String ruta) {
        try {
            imagen = ImageIO.read(new File(ruta));
            repaint();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (imagen != null) {
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        
        }
    }
}